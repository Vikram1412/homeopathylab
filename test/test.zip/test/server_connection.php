<?php

$con=mysqli_connect('localhost','tamsa','ashutosh@276141','tamsa_autotreatment');

if(empty($con)){

	echo"Data base not connected.";
}

?>