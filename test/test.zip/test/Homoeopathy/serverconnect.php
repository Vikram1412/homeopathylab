<?php 
$host="localhost";
$username="tamsa";
$password="ashutosh@276141";
$database="tamsa_autotreatment";

$con=mysqli_connect($host,$username,$password,$database);

?>