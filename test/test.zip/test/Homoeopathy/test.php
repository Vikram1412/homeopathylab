
<div id="google_element"></div>
<h1>Welcome in my web application.</h1>

<h3>I am Vikram Nishad.Today I will do better job.</h3>


<script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
<script type="text/javascript">
 
 function loadGoogleTranslate(){
     
     new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_element'
         
         );
}

</script>