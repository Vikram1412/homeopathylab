<!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a href="index.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
               <!--  <li class="sub-menu">
                   <a href="javascript:;">
                       <i class="fa fa-book"></i>
                       <span></span>
                   </a>
                   <ul class="sub">
                       
                                       <li><a href="">Typography</a></li>
                                       <li><a href="">glyphicon</a></li>
                       <li><a href="">Grids</a></li>
                   </ul>
               </li> -->
                    <li>
                    <a href="patient_list.php">
                        <i class="fa fa-edit"></i>
                        <span> Patient list </span>
                    </a>
                </li>
               <!--start below is submenu-->
                <li class="sub-menu">
                            <a class="active" href="javascript:;">
                                <i class="fa fa-medkit"></i>
                                <span>Treatment Tools</span>
                            </a>
                            <ul class="sub">
                                
                         <li>
                            <a href="category.php">
                                <i class="fa fa-plus-square"></i>
                                <span> Category </span>
                            </a>
                        </li>
                        <li>
                            <a href="subcategory.php">
                                <i class="fa fa-plus-square "></i>
                                <span> Sub category </span>
                            </a>
                        </li>
        
                        <li>
                            <a href="simtoms.php">
                                <i class="fa fa-list"></i>
                                <span> Symtom list</span>
                            </a>
                        </li>
        
                         <li>
                            <a href="medicine_list.php">
                                <i class="fa fa-list"></i>
                                <span> Medicine List </span>
                            </a>
                        </li>
        
        
                         <li>
                            <a href="find_remdy.php">
                                <i class="fa fa-edit"></i>
                                <span> Define remedy </span>
                            </a>
                        </li>
                   
                   </ul>
                </li>
                
                <!--end below is submenu-->
                
                <li>
                    <a href="logout.php">
                        <i class="fa fa-sign-out "></i>
                        <span> Logout </span>
                    </a>
                </li>

      <!--     <li class="sub-menu">
                    <a class="active" href="javascript:;">
                        <i class="fa fa-th"></i>
                        <span>Data Tables</span>
                    </a>
                    <ul class="sub">
                        <li><a href="">Basic Table</a></li>
                        <li><a class="active" href="#">Responsive Table</a></li>
                    </ul>
                </li>-->
                
                
                
               
                
              
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>