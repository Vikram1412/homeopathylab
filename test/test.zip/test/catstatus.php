<?php 

$sid = intval($_GET['q2']);


//echo$simtom_id;
//exit;

/*start this is database connection file*/

include('serverconnect.php');


 /*$sql4="UPDATE `category` SET `id`=[value-1],`catname`=[value-2],`descrition`=[value-3],`active`=[value-4] WHERE 1 = '".$sid."'";
  $run4=mysqli_query($con,$sql4);*/

  
?>